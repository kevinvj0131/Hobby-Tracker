//
//  assignment0Tests.swift
//  assignment0Tests
//
//  Created by Kevin Jones on 2/19/25.
//

import Testing
@testable import assignment0

struct assignment0Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
