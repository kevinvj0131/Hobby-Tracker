//
//  assignment0App.swift
//  assignment0
//
//  Created by Kevin Jones on 2/19/25.
//

import SwiftUI

@main
struct assignment0App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
